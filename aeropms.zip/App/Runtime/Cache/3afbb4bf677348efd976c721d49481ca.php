<?php if (!defined('THINK_PATH')) exit();?><div class="page-header">
	<h1><?php echo ($name); ?></h1>
</div>