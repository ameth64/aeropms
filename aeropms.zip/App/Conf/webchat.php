<?php
return array (
  'SITE_NAME' => 'smeoa',
  'SITE_URL' => 'http://demo.smeoa.com',
  'WECHAT_TOKEN' => 'smeoasmeoasmeoa',
  'WECHAT_APPID' => 'wxf1d6276b520a93ea',
  'WECHAT_APPSECRET' => '229c5e1670bbd86cdee13ad4e4a1934a',
);
?>