<?php
return array(
	'AUTH' => array(
		'index' => 'read',
		'read' => 'read',
		'down' => 'read',
		'add' => 'write',
		'edit' => 'write',
		'upload' => 'write', 
		'del_file' => 'write',
		'save' => 'write', 
		'del' => 'admin', 
		'restore' => 'admin', 
		'destory' => 'admin', 
		'import' => 'admin', 
		'export' => 'read',
		'folder' => 'read'
		)
	);
